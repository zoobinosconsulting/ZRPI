/* hello.c: A standard "Hello, world!" program */
 
#include <stdio.h>
 
int main(int argc, char* argv[])
{
   printf("Hello, world! (autotools)\n");

   return 0;
}
